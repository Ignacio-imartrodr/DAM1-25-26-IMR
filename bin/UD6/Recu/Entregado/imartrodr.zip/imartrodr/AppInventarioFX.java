package ud6.examenrec.imartrodr;

/**
 * @author Ignacio Martínez Rodríguez
 */
public class AppInventarioFX {

}
